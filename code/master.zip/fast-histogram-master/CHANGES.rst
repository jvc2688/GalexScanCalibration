0.3 (unreleased)
----------------

- Use long instead of int for x/y sizes and indices

0.2.1 (2017-07-18)
------------------

- Fixed rst syntax in README

0.2 (2017-07-18)
----------------

- Fixed segmentation fault under certain conditions.

- Ensure that arrays are C-contiguous before passing them to the C code.

0.1 (2017-07-18)
----------------

- Initial version
